package pe.edu.upc.valenzuelarecoba.vhrfrepositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upc.valenzuelarecoba.vhrfentities.Zona;

import java.util.List;

@Repository
public interface IZonaRepository extends JpaRepository<Zona, Long> {

    @Query(value = "SELECT z.rfvh_name AS zona, COUNT(m.rfvh_id_monitoreo) AS cantidad_monitoreos " +
            "FROM zona z INNER JOIN monitoreo_ecologico m ON z.rfvh_id_zona = m.id_zona " +
            "GROUP BY z.rfvh_id_zona, z.rfvh_name " +
            "ORDER BY cantidad_monitoreos DESC", nativeQuery = true)
    List<Object[]> cantidadMonitoreosPorZona();
}
