package pe.edu.upc.valenzuelarecoba.vhrfservicesimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.edu.upc.valenzuelarecoba.vhrfentities.Zona;
import pe.edu.upc.valenzuelarecoba.vhrfrepositories.IZonaRepository;
import pe.edu.upc.valenzuelarecoba.vhrfservicesinterfaces.IZonaService;

import java.util.List;
import java.util.Optional;

@Service
public class ZonaServiceImplements implements IZonaService {

    @Autowired
    private IZonaRepository repo;

    @Override
    public Optional<Zona> listId(Long id) {
        return repo.findById(id);
    }

    @Override
    public void delete(Long id) {
        repo.deleteById(id);
    }

    @Override
    public List<Object[]> cantidadMonitoreosPorZona() {
        return repo.cantidadMonitoreosPorZona();
    }
}
