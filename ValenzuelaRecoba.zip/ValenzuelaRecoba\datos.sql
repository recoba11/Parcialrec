-- ejecutar en BDParcialValenzuela despues de levantar la app una vez (ddl-auto=update crea las tablas)
-- la zona 6 no tiene especies ni monitoreos: sirve para probar el HTTP 204 de HUB01
insert into zona (rfvh_name, rfvh_location, rfvh_area_hectares, rfvh_intervention_date, rfvh_status) values ('Pantanos de Villa', 'Chorrillos, Lima', 263.27, '2024-03-15', 'En recuperacion');
insert into zona (rfvh_name, rfvh_location, rfvh_area_hectares, rfvh_intervention_date, rfvh_status) values ('Humedales de Ventanilla', 'Ventanilla, Callao', 275.45, '2024-05-20', 'En recuperacion');
insert into zona (rfvh_name, rfvh_location, rfvh_area_hectares, rfvh_intervention_date, rfvh_status) values ('Albufera de Medio Mundo', 'Vegueta, Huaura', 687.71, '2023-11-10', 'Restaurada');
insert into zona (rfvh_name, rfvh_location, rfvh_area_hectares, rfvh_intervention_date, rfvh_status) values ('Humedal de Puerto Viejo', 'San Antonio, Cañete', 275.81, '2025-01-08', 'Critica');
insert into zona (rfvh_name, rfvh_location, rfvh_area_hectares, rfvh_intervention_date, rfvh_status) values ('Humedales de Eten', 'Puerto Eten, Lambayeque', 112.50, '2025-04-22', 'En recuperacion');
insert into zona (rfvh_name, rfvh_location, rfvh_area_hectares, rfvh_intervention_date, rfvh_status) values ('Laguna El Paraiso', 'Huacho, Huaura', 95.30, '2025-08-01', 'Critica');

insert into especie (rfvh_common_name, rfvh_scientific_name, rfvh_conservation_status, rfvh_ecological_role, id_zona) values ('Totora', 'Schoenoplectus californicus', 'Preocupacion menor', 'Filtra el agua y sirve de refugio para aves', 1);
insert into especie (rfvh_common_name, rfvh_scientific_name, rfvh_conservation_status, rfvh_ecological_role, id_zona) values ('Garza blanca', 'Ardea alba', 'Preocupacion menor', 'Controla poblaciones de peces e insectos', 1);
insert into especie (rfvh_common_name, rfvh_scientific_name, rfvh_conservation_status, rfvh_ecological_role, id_zona) values ('Gallareta andina', 'Fulica ardesiaca', 'Preocupacion menor', 'Dispersa semillas de plantas acuaticas', 2);
insert into especie (rfvh_common_name, rfvh_scientific_name, rfvh_conservation_status, rfvh_ecological_role, id_zona) values ('Junco', 'Schoenoplectus americanus', 'Preocupacion menor', 'Estabiliza el suelo y evita la erosion', 3);
insert into especie (rfvh_common_name, rfvh_scientific_name, rfvh_conservation_status, rfvh_ecological_role, id_zona) values ('Pejerrey', 'Odontesthes regia', 'Vulnerable', 'Indicador de la calidad del agua', 4);

insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-02-10', 'Regular', 45.5, 120, 'Se observa recuperacion de totorales en el sector norte', 1);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-06-15', 'Buena', 58.0, 165, 'Aumento de aves migratorias', 1);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-10-20', 'Buena', 66.3, 190, 'Nivel de agua estable', 1);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-03-05', 'Mala', 30.2, 75, 'Presencia de residuos solidos en la orilla', 2);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-09-12', 'Regular', 38.7, 98, 'Se retiraron residuos y mejoro la cobertura', 2);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-04-18', 'Buena', 72.4, 210, 'Zona estable, se mantiene el control', 3);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-07-25', 'Mala', 18.9, 40, 'Avance urbano afecta el borde sur', 4);
insert into monitoreo_ecologico (rfvh_record_date, rfvh_water_quality, rfvh_vegetation_coverage, rfvh_fauna_count, rfvh_observations, id_zona) values ('2025-08-30', 'Regular', 35.0, 62, 'Inicio de reforestacion con especies nativas', 5);
