package pe.edu.upc.valenzuelarecoba;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValenzuelaRecobaApplication {
    public static void main(String[] args) {
        SpringApplication.run(ValenzuelaRecobaApplication.class, args);
    }
}
