package pe.edu.upc.valenzuelarecoba.vhrfentities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

@Entity
@Table(name = "zona")
public class Zona implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rfvhIdZona;

    @Column(nullable = false)
    private String rfvhName;

    @Column(nullable = false)
    private String rfvhLocation;

    @Column(nullable = false)
    private Double rfvhAreaHectares;

    private LocalDate rfvhInterventionDate;

    @Column(nullable = false)
    private String rfvhStatus;

    @OneToMany(mappedBy = "rfvhZona", fetch = FetchType.LAZY)
    private List<Especie> rfvhEspecies;

    @OneToMany(mappedBy = "rfvhZona", fetch = FetchType.LAZY)
    private List<MonitoreoEcologico> rfvhMonitoreos;

    public Long getRfvhIdZona() { return rfvhIdZona; }
    public void setRfvhIdZona(Long rfvhIdZona) { this.rfvhIdZona = rfvhIdZona; }

    public String getRfvhName() { return rfvhName; }
    public void setRfvhName(String rfvhName) { this.rfvhName = rfvhName; }

    public String getRfvhLocation() { return rfvhLocation; }
    public void setRfvhLocation(String rfvhLocation) { this.rfvhLocation = rfvhLocation; }

    public Double getRfvhAreaHectares() { return rfvhAreaHectares; }
    public void setRfvhAreaHectares(Double rfvhAreaHectares) { this.rfvhAreaHectares = rfvhAreaHectares; }

    public LocalDate getRfvhInterventionDate() { return rfvhInterventionDate; }
    public void setRfvhInterventionDate(LocalDate rfvhInterventionDate) { this.rfvhInterventionDate = rfvhInterventionDate; }

    public String getRfvhStatus() { return rfvhStatus; }
    public void setRfvhStatus(String rfvhStatus) { this.rfvhStatus = rfvhStatus; }

    public List<Especie> getRfvhEspecies() { return rfvhEspecies; }
    public void setRfvhEspecies(List<Especie> rfvhEspecies) { this.rfvhEspecies = rfvhEspecies; }

    public List<MonitoreoEcologico> getRfvhMonitoreos() { return rfvhMonitoreos; }
    public void setRfvhMonitoreos(List<MonitoreoEcologico> rfvhMonitoreos) { this.rfvhMonitoreos = rfvhMonitoreos; }
}
