package pe.edu.upc.valenzuelarecoba.vhrfservicesinterfaces;

import pe.edu.upc.valenzuelarecoba.vhrfentities.Zona;

import java.util.List;
import java.util.Optional;

public interface IZonaService {
    Optional<Zona> listId(Long id);
    void delete(Long id);
    List<Object[]> cantidadMonitoreosPorZona();
}
