package pe.edu.upc.valenzuelarecoba.vhrfentities;

import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "especie")
public class Especie implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rfvhIdEspecie;

    @Column(nullable = false)
    private String rfvhCommonName;

    @Column(nullable = false)
    private String rfvhScientificName;

    @Column(nullable = false)
    private String rfvhConservationStatus;

    @Column(nullable = false)
    private String rfvhEcologicalRole;

    @ManyToOne
    @JoinColumn(name = "id_zona", nullable = false)
    private Zona rfvhZona;

    public Long getRfvhIdEspecie() { return rfvhIdEspecie; }
    public void setRfvhIdEspecie(Long rfvhIdEspecie) { this.rfvhIdEspecie = rfvhIdEspecie; }

    public String getRfvhCommonName() { return rfvhCommonName; }
    public void setRfvhCommonName(String rfvhCommonName) { this.rfvhCommonName = rfvhCommonName; }

    public String getRfvhScientificName() { return rfvhScientificName; }
    public void setRfvhScientificName(String rfvhScientificName) { this.rfvhScientificName = rfvhScientificName; }

    public String getRfvhConservationStatus() { return rfvhConservationStatus; }
    public void setRfvhConservationStatus(String rfvhConservationStatus) { this.rfvhConservationStatus = rfvhConservationStatus; }

    public String getRfvhEcologicalRole() { return rfvhEcologicalRole; }
    public void setRfvhEcologicalRole(String rfvhEcologicalRole) { this.rfvhEcologicalRole = rfvhEcologicalRole; }

    public Zona getRfvhZona() { return rfvhZona; }
    public void setRfvhZona(Zona rfvhZona) { this.rfvhZona = rfvhZona; }
}
