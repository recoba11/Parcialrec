-- ejecutar en BDParcialValenzuela despues de levantar la app una vez (ddl-auto=update crea las tablas)
-- clave de todos los usuarios: 123
insert into users (id, username, password, enabled) values (1, 'administrador', '$2a$10$quhGc2np5cgrfMkJTFrWFuCEyotP/zKOQ7AoPzz1vuhv6hg5HZsKK', true);
insert into users (id, username, password, enabled) values (2, 'desarrollador', '$2a$10$quhGc2np5cgrfMkJTFrWFuCEyotP/zKOQ7AoPzz1vuhv6hg5HZsKK', true);
insert into roles (id, rol, user_id) values (1, 'ADMINISTRADOR', 1);
insert into roles (id, rol, user_id) values (2, 'DESARROLLADOR', 2);
