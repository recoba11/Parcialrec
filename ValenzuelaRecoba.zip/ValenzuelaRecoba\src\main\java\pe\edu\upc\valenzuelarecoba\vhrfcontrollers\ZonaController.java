package pe.edu.upc.valenzuelarecoba.vhrfcontrollers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pe.edu.upc.valenzuelarecoba.vhrfdtos.ZonaMonitoreoDTO;
import pe.edu.upc.valenzuelarecoba.vhrfentities.Zona;
import pe.edu.upc.valenzuelarecoba.vhrfservicesinterfaces.IZonaService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/valenzuela")
public class ZonaController {

    @Autowired
    private IZonaService zS;

    // HUB01: Eliminar zona - rol ADMINISTRADOR
    @DeleteMapping("/zones/{id}")
    @PreAuthorize("hasAuthority('ADMINISTRADOR')")
    public ResponseEntity<?> eliminar(@PathVariable("id") Long id) {
        Optional<Zona> zona = zS.listId(id);
        if (zona.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No existe la zona con ID: " + id);
        }
        try {
            zS.delete(id);
        } catch (DataIntegrityViolationException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body("No se puede eliminar la zona con ID: " + id + " porque tiene especies o monitoreos relacionados");
        }
        return ResponseEntity.noContent().build();
    }

    // HUB02: Cantidad total de monitoreos por zona - acceso libre sin token
    @GetMapping("/zones-free")
    public ResponseEntity<?> cantidadMonitoreosPorZona() {
        List<Object[]> lista = zS.cantidadMonitoreosPorZona();
        List<ZonaMonitoreoDTO> listaDTO = lista.stream().map(x -> {
            ZonaMonitoreoDTO dto = new ZonaMonitoreoDTO();
            dto.setZona(x[0].toString());
            dto.setCantidad_monitoreos(Integer.parseInt(x[1].toString()));
            return dto;
        }).collect(Collectors.toList());
        return ResponseEntity.ok(listaDTO);
    }
}
