package pe.edu.upc.valenzuelarecoba.vhrfdtos;

import java.io.Serializable;
import java.time.LocalDate;

public class ZonaDTO implements Serializable {

    private Long rfvhIdZona;
    private String rfvhName;
    private String rfvhLocation;
    private Double rfvhAreaHectares;
    private LocalDate rfvhInterventionDate;
    private String rfvhStatus;

    public Long getRfvhIdZona() { return rfvhIdZona; }
    public void setRfvhIdZona(Long rfvhIdZona) { this.rfvhIdZona = rfvhIdZona; }

    public String getRfvhName() { return rfvhName; }
    public void setRfvhName(String rfvhName) { this.rfvhName = rfvhName; }

    public String getRfvhLocation() { return rfvhLocation; }
    public void setRfvhLocation(String rfvhLocation) { this.rfvhLocation = rfvhLocation; }

    public Double getRfvhAreaHectares() { return rfvhAreaHectares; }
    public void setRfvhAreaHectares(Double rfvhAreaHectares) { this.rfvhAreaHectares = rfvhAreaHectares; }

    public LocalDate getRfvhInterventionDate() { return rfvhInterventionDate; }
    public void setRfvhInterventionDate(LocalDate rfvhInterventionDate) { this.rfvhInterventionDate = rfvhInterventionDate; }

    public String getRfvhStatus() { return rfvhStatus; }
    public void setRfvhStatus(String rfvhStatus) { this.rfvhStatus = rfvhStatus; }
}
