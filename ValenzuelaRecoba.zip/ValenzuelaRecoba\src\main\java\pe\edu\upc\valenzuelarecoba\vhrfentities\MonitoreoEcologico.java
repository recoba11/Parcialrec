package pe.edu.upc.valenzuelarecoba.vhrfentities;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDate;

@Entity
@Table(name = "monitoreo_ecologico")
public class MonitoreoEcologico implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long rfvhIdMonitoreo;

    @Column(nullable = false)
    private LocalDate rfvhRecordDate;

    @Column(nullable = false)
    private String rfvhWaterQuality;

    @Column(nullable = false)
    private Double rfvhVegetationCoverage;

    @Column(nullable = false)
    private Integer rfvhFaunaCount;

    private String rfvhObservations;

    @ManyToOne
    @JoinColumn(name = "id_zona", nullable = false)
    private Zona rfvhZona;

    public Long getRfvhIdMonitoreo() { return rfvhIdMonitoreo; }
    public void setRfvhIdMonitoreo(Long rfvhIdMonitoreo) { this.rfvhIdMonitoreo = rfvhIdMonitoreo; }

    public LocalDate getRfvhRecordDate() { return rfvhRecordDate; }
    public void setRfvhRecordDate(LocalDate rfvhRecordDate) { this.rfvhRecordDate = rfvhRecordDate; }

    public String getRfvhWaterQuality() { return rfvhWaterQuality; }
    public void setRfvhWaterQuality(String rfvhWaterQuality) { this.rfvhWaterQuality = rfvhWaterQuality; }

    public Double getRfvhVegetationCoverage() { return rfvhVegetationCoverage; }
    public void setRfvhVegetationCoverage(Double rfvhVegetationCoverage) { this.rfvhVegetationCoverage = rfvhVegetationCoverage; }

    public Integer getRfvhFaunaCount() { return rfvhFaunaCount; }
    public void setRfvhFaunaCount(Integer rfvhFaunaCount) { this.rfvhFaunaCount = rfvhFaunaCount; }

    public String getRfvhObservations() { return rfvhObservations; }
    public void setRfvhObservations(String rfvhObservations) { this.rfvhObservations = rfvhObservations; }

    public Zona getRfvhZona() { return rfvhZona; }
    public void setRfvhZona(Zona rfvhZona) { this.rfvhZona = rfvhZona; }
}
