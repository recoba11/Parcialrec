package pe.edu.upc.valenzuelarecoba.vhrfdtos;

import java.io.Serializable;

public class ZonaMonitoreoDTO implements Serializable {

    private String zona;
    private Integer cantidad_monitoreos;

    public String getZona() { return zona; }
    public void setZona(String zona) { this.zona = zona; }

    public Integer getCantidad_monitoreos() { return cantidad_monitoreos; }
    public void setCantidad_monitoreos(Integer cantidad_monitoreos) { this.cantidad_monitoreos = cantidad_monitoreos; }
}
